var email = "astolofo@gmail.com" 
var usuario = "astolfo"
var senha = "2023"


function login() {
    var tentativausuario = document.getElementById ("iduser").value;
    var tentativaemail = document.getElementById("idemail").value;
    var tentativasenha = document.getElementById("idsenha").value;

    if (idemail === '' || iduser === '' || idsenha === '') {
        alert('Por favor, preencha todos os campos.');
        return;
    } 
    else {
        alert("Senha incorreta, tente novamente");
        window.location.href = "index.html";
    }
}
if (email === 'exemplo@email.com' && username === 'usuario' && password === 'senha123') {
    alert('Login realizado com sucesso!');
} else {
    alert('Credenciais inválidas. Tente novamente.');
}
